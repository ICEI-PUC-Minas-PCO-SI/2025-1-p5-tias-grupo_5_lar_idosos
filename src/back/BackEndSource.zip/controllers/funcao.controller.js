const Funcao = require('../models/funcao.model');

exports.getAll = async (req, res) => {
  // Ajustei pra filtrar as funcoes do usuario autenticado
  const usuarioId = req.usuario?.id;
  if (!usuarioId) {
    return res.status(401).json({ error: 'Usuário não autenticado' });
  }
  const funcoes = await Funcao.findAll({ where: { IdUsuario: usuarioId } });
  res.json(funcoes);
};

exports.getById = async (req, res) => {
  const item = await Funcao.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  res.json(item);
};

exports.create = async (req, res) => {
  const novo = await Funcao.create(req.body);
  res.status(201).json(novo);
};

exports.update = async (req, res) => {
  const item = await Funcao.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  await item.update(req.body);
  res.json(item);
};

exports.delete = async (req, res) => {
  const item = await Funcao.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  await item.destroy();
  res.status(204).send();
};
