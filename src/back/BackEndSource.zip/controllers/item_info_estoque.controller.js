const ItemInfoEstoque = require('../models/item_info_estoque.model');

exports.getAll = async (req, res) => {
  const data = await ItemInfoEstoque.findAll();
  res.json(data);
};

exports.getById = async (req, res) => {
  const item = await ItemInfoEstoque.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  res.json(item);
};

exports.create = async (req, res) => {
  const novo = await ItemInfoEstoque.create(req.body);
  res.status(201).json(novo);
};

exports.update = async (req, res) => {
  const item = await ItemInfoEstoque.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  await item.update(req.body);
  res.json(item);
};

exports.delete = async (req, res) => {
  const item = await ItemInfoEstoque.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  await item.destroy();
  res.status(204).send();
};
