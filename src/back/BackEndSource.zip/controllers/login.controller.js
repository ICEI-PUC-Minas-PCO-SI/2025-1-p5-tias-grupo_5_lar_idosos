const Login = require('../models/login.model');
const bcrypt = require('bcryptjs');

exports.getAll = async (req, res) => {
  const data = await Login.findAll();
  res.json(data);
};

exports.getById = async (req, res) => {
  const item = await Login.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  res.json(item);
};

exports.create = async (req, res) => {
  try {
    const dados = { ...req.body };

    if (!dados.Senha) {
      return res.status(400).json({ error: 'Senha é obrigatória' });
    }

    dados.Senha = await bcrypt.hash(dados.Senha, 10);

    const novo = await Login.create(dados);
    res.status(201).json(novo);
  } catch (err) {
    console.error('Erro ao criar login:', err);
    res.status(500).json({ error: 'Erro ao criar login' });
  }
};

exports.update = async (req, res) => {
  try {
    const item = await Login.findByPk(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Não encontrado' });
    }

    const dadosAtualizados = { ...req.body };

    if (dadosAtualizados.Senha) {
      dadosAtualizados.Senha = await bcrypt.hash(dadosAtualizados.Senha, 10);
    }

    await item.update(dadosAtualizados);
    res.json(item);
  } catch (err) {
    console.error('Erro ao atualizar login:', err);
    res.status(500).json({ error: 'Erro ao atualizar login' });
  }
};

exports.delete = async (req, res) => {
  const item = await Login.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  await item.destroy();
  res.status(204).send();
};
