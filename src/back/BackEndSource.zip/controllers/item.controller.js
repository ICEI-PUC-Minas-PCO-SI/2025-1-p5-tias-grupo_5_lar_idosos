const Item = require('../models/item.model');
const ItemInfoEstoque = require('../models/item_info_estoque.model');
const MovItem = require('../models/movimentacao_item.model')
const Utils = require('../Utils/Utilidades')

exports.getAll = async (req, res) => {
  const data = await Item.findAll();
  res.json(data);
};

exports.getById = async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  res.json(item);
};

// A ideia seria o "InfoEstoque" ser de controle interno, entao o CRUD seria feito de acordo com as modificacoes do item
exports.create = async (req, res) => {
  const novo = await Item.create(req.body);
  res.status(201).json(novo);
};

// se o usuario nao for gerente ele nao pode mudar o cadastro do item, so quantidade
// Toda vez que a quantidade for alterada, um registro de modificacao deve ser criado
exports.update = async (req, res) => {

  const isGerente = Utils.CheckAuthenticatedUserIsManager(req);
  console.log(req.params)
  const item = await Item.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });

  const quantidade = req.body.quantidadeNoEstoque

  if (quantidade) {
    if (item.quantidadeNoEstoque != quantidade) {
      const mov_data = {
        Direcao: (item.quantidadeNoEstoque < quantidade) ? 1 : 2, // 1 Entrada e 2
        Quantidade: Math.abs(item.quantidadeNoEstoque - quantidade),
        DataHora: new Date().toString(),
        CriadoPor: req.usuario?.id,
        IdItem: item.Id,
      }
      MovItem.create(mov_data)
    }
  }

  if (!isGerente) {
    res.json(item);
    return
  }

  await item.update(req.body);
  res.json(item);
};

exports.delete = async (req, res) => {
  const item = await Item.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });

  // Apaga todas as movimentações relacionadas a esse item
  await MovItem.destroy({
    where: { IdItem: item.Id }
  });

  await item.destroy();
  res.status(204).send();
};

exports.getByCategoria = async (req, res) => {
  const categoria = req.params.categoria;
  const idResidente = req.params.idResidente;
  const isDashboard = req.params.isDashboard === 'true';

  const where = { CategoriaItem: categoria };
  if (!isDashboard) {
    if (idResidente === 'null' || idResidente === '' || idResidente === null || idResidente === undefined) {
      where.IdResidente = null;
    } else {
      where.IdResidente = idResidente;
    }
  }

  const itens = await Item.findAll({ where });
  res.json(itens);
};
