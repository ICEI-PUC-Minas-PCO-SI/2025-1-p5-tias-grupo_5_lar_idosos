const Login = require('../models/login.model');
const Usuario = require('../models/usuario.model');
const Utils = require('../Utils/Utilidades')

exports.getAll = async (req, res) => {
  const data = await Usuario.findAll();
  res.json(data);
};

exports.getById = async (req, res) => {
  const item = await Usuario.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  res.json(item);
};

exports.create = async (req, res) => {
  req.body.IdEmpresa = Utils.GetAuthenticatedUserCompany(req);
  const novo = await Usuario.create(req.body);
  res.status(201).json(novo);
};

exports.update = async (req, res) => {
  const item = await Usuario.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  req.body.IdEmpresa = Utils.GetAuthenticatedUserCompany(req);
  await item.update(req.body);
  res.json(item);
};

exports.delete = async (req, res) => {
  const item = await Usuario.findByPk(req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });
  await item.destroy();
  res.status(204).send();
};
