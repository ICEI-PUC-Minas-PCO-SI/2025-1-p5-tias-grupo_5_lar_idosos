const ConstantesFuncoes = require('..//Constants/ConstsFuncoes')

module.exports = (...funcoesPermitidas) => {
  return (req, res, next) => {
    const usuario = req.usuario;

    if (!usuario || !usuario.funcoes) {
      return res.status(403).json({ error: 'Acesso não autorizado' });
    }

    const possuiPermissao = usuario.funcoes.some(f =>
      funcoesPermitidas.includes(f) ||
      f === ConstantesFuncoes.Administracao ||
      f === ConstantesFuncoes.Gerencia
    );

    if (!possuiPermissao) {
      return res.status(403).json({ error: 'Função não autorizada' });
    }

    next();
  };
}