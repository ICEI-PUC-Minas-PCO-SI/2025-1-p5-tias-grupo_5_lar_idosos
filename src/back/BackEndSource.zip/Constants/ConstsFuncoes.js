const Funcoes = Object.freeze({
  Administracao: 1,
  Gerencia: 2,
  Enfermagem: 3,
  Culinaria: 4,
  Limpeza: 5,
  CuidadosPessoais: 6
});

module.exports = Funcoes;