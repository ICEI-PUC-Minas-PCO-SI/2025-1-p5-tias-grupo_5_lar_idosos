const Categorias = Object.freeze({
  Pessoal: 1,
  Medicamento: 2,
  Cozinha: 3,
  Limpeza: 4,
});

module.exports = Categorias;