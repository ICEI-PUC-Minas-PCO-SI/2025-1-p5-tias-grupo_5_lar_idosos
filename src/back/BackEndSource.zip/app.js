const express = require('express');
const cors = require('cors');

const app = express();
const sequelize = require('./config/db');

app.use(cors());
app.use(express.json());
app.use('/api/usuario', require('./routes/usuario.routes'));
app.use('/api/empresa', require('./routes/empresa.routes'));
app.use('/api/filial', require('./routes/filial.routes'));
app.use('/api/residente', require('./routes/residente.routes'));
app.use('/api/item', require('./routes/item.routes'));
app.use('/api/item_info_estoque', require('./routes/item_info_estoque.routes'));
app.use('/api/movimentacao_item', require('./routes/movimentacao_item.routes'));
app.use('/api/login', require('./routes/login.routes'));
app.use('/api/funcao', require('./routes/funcao.routes'));
app.use('/api/filial_usuario', require('./routes/filial_usuario.routes'));
app.use('/api/auth', require('./routes/auth.routes'));

sequelize.sync().then(() => console.log("Banco sincronizado"));
module.exports = app;
