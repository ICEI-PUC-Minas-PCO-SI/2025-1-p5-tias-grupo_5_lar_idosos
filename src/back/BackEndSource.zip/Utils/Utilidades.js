const ConstantesFuncoes = require('../Constants/ConstsFuncoes');

class Utils {
  static CheckAuthenticatedUserIsManager(req) {
    const funcoes = req.usuario?.funcoes || [];
    return funcoes.includes(ConstantesFuncoes.Gerencia) ||
           funcoes.includes(ConstantesFuncoes.Administracao);
  }

  static GetAuthenticatedUserId(req) {
    return req.usuario?.id
  }

  static GetAuthenticatedUserFunctions(req) {
    return req.usuario?.funcoes
  }

  static GetAuthenticatedUserCompany(req) {
    console.log(req.usuario)
    return req.usuario?.idEmpresa
  }
}

module.exports = Utils;

