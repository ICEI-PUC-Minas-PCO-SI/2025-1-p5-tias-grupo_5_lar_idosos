const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Residente = sequelize.define('residente', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Nome: { type: DataTypes.STRING, allowNull: false },
  Cpf: { type: DataTypes.STRING(12), allowNull: false },
  DataNascimento: { type: DataTypes.DATE, allowNull: false },
  Observacoes: { type: DataTypes.STRING },
  CriadoPor: { type: DataTypes.INTEGER, allowNull: false },
  DataCriacao: { type: DataTypes.DATE, allowNull: false },
  UltimaModificacao: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  DataEntrada: { type: DataTypes.DATE, allowNull: false },
  IdFilial: { type: DataTypes.INTEGER, allowNull: false }
}, {
  tableName: 'residente',
  timestamps: false
});

module.exports = Residente;