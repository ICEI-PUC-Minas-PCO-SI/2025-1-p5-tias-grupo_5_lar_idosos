const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Login = sequelize.define('login', {
  IdUsuario: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Senha: { type: DataTypes.STRING, allowNull: false },
  HostAcesso: { type: DataTypes.STRING },
  UltimoAcesso: { type: DataTypes.DATE, allowNull: false }
}, {
  tableName: 'login',
  timestamps: false
});

module.exports = Login;
