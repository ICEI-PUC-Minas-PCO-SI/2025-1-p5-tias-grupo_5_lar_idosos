const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Usuario = sequelize.define('usuario', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Cpf: { type: DataTypes.STRING(12), allowNull: false },
  Nome: { type: DataTypes.STRING },
  UltimaModificacao: { type: DataTypes.DATE, allowNull: false },
  IdEmpresa: { type: DataTypes.INTEGER, allowNull: false }
}, {
  tableName: 'usuario',
  timestamps: false
});

module.exports = Usuario;
