const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Empresa = sequelize.define('empresa', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  razao_social: { type: DataTypes.STRING, allowNull: false }
}, {
  tableName: 'empresa',
  timestamps: false
});

module.exports = Empresa;
