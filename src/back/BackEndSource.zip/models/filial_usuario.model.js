const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const FilialUsuario = sequelize.define('filial_usuario', {
  IdUsuario: { type: DataTypes.INTEGER, primaryKey: true },
  IdFilial: { type: DataTypes.INTEGER, primaryKey: true },
  DataInclusao: { type: DataTypes.DATE, allowNull: false }
}, {
  tableName: 'filial_usuario',
  timestamps: false
});

module.exports = FilialUsuario;
