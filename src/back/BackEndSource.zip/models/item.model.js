const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Item = sequelize.define('item', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Nome: { type: DataTypes.STRING(255), allowNull: false },
  CategoriaItem: { type: DataTypes.INTEGER, allowNull: false },
  Medida: { type: DataTypes.INTEGER, allowNull: true },
  Descricao: { type: DataTypes.TEXT },
  IdFilial: { type: DataTypes.INTEGER, allowNull: false },
  IdResidente: { type: DataTypes.INTEGER, allowNull: true },
  CriadoPor: { type: DataTypes.INTEGER, allowNull: false },
  DataCriacao: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
  UltimaModificacao: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
  ItemInfoEstoqueId: { type: DataTypes.INTEGER, allowNull: true },
  quantidadeNoEstoque: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, defaultValue: 0 },
  quantidadeMinima: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, defaultValue: 0 },
  unidade: { type: DataTypes.STRING(20), allowNull: false },
  codigoBarras: { type: DataTypes.STRING(50), allowNull: true, unique: true },
  tipo: { type: DataTypes.STRING(50), allowNull: true },
}, {
  tableName: 'item',
  timestamps: false,
});

module.exports = Item;
