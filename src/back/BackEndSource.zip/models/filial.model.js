const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Filial = sequelize.define('filial', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Nome: { type: DataTypes.STRING, allowNull: false },
  Endereco: { type: DataTypes.STRING },
  Cnpj: { type: DataTypes.STRING },
  IdEmpresa: { type: DataTypes.INTEGER, allowNull: false }
}, {
  tableName: 'filial',
  timestamps: false
});

module.exports = Filial;
