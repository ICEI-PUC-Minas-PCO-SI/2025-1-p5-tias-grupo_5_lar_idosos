const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const ItemInfoEstoque = sequelize.define('item_info_estoque', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  QuantidadeNoEstoque: { type: DataTypes.FLOAT, allowNull: false },
  QuantidadeMinima: { type: DataTypes.FLOAT, allowNull: false }
}, {
  tableName: 'item_info_estoque',
  timestamps: false
});

module.exports = ItemInfoEstoque;
