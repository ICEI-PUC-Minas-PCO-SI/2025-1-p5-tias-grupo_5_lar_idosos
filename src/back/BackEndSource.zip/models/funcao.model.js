const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Funcao = sequelize.define('funcao', {
  IdEmpresa: { type: DataTypes.INTEGER, primaryKey: true },
  IdUsuario: { type: DataTypes.INTEGER, primaryKey: true },
  CodigoFuncao: { type: DataTypes.INTEGER, primaryKey: true },
  UsuarioId: { type: DataTypes.INTEGER }
}, {
  tableName: 'funcao',
  timestamps: false
});

module.exports = Funcao;
