const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const MovimentacaoItem = sequelize.define('movimentacao_item', {
  Id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  Direcao: { type: DataTypes.INTEGER, allowNull: false },
  Quantidade: { type: DataTypes.FLOAT, allowNull: false },
  DataHora: { type: DataTypes.DATE, allowNull: false },
  CriadoPor: { type: DataTypes.INTEGER, allowNull: false },
  IdItem: { type: DataTypes.INTEGER, allowNull: false },
  Observacao: { type: DataTypes.STRING }
}, {
  tableName: 'movimentacao_item',
  timestamps: false
});

module.exports = MovimentacaoItem;
