const express = require('express');

const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Op } = require('sequelize');
require('dotenv').config();

const Usuario = require('../models/usuario.model')
const Funcao = require('../models/funcao.model')
const Login = require('../models/login.model');
const Filial = require('../models/filial.model');
const Empresa = require('../models/empresa.model');
const auth = require('../middleware/auth');

const ConstantesFuncoes = require('../Constants/ConstsFuncoes')

router.post('/login', async (req, res) => {

  const Senha = req.body.Senha || req.body.senha;
  const rawCpf = req.body.Cpf || req.body.cpf;

  if (!rawCpf || !Senha)
    return res.status(401).json({ error: 'Credenciais inválidas' });

  const Cpf = rawCpf.replace(/\D/g, '');

  const usuario = await Usuario.findOne({ where: { Cpf: Cpf } });

  if (!usuario) 
    return res.status(401).json({ error: 'Credenciais inválidas' });

  const IdUsuario = usuario.Id;
  const registro = await Login.findOne({ where: { IdUsuario } });

  if (!registro) 
    return res.status(401).json({ error: 'Credenciais inválidas' });

  const senhaValida = await bcrypt.compare(Senha, registro.Senha);

  if (!senhaValida)
    return res.status(401).json({ error: 'Credenciais inválidas' });
  
  const funcoes = await Funcao.findAll({
      where: { IdUsuario: IdUsuario }
    });

  const codigosFuncoes = funcoes.map(f => f.CodigoFuncao);

  if (!codigosFuncoes.includes(ConstantesFuncoes.Administracao) &&
      !codigosFuncoes.includes(ConstantesFuncoes.Gerencia)) {
    return res.status(401).json({ error: 'Acesso restrito à administração ou gerência' });
  }

  registro.UltimoAcesso = new Date().toString()
  registro.save()

  const payload = {
    id: IdUsuario,
    idEmpresa: usuario.IdEmpresa,
    funcoes: codigosFuncoes
  };

  try {

    const token = jwt.sign(payload, process.env.SECRET_KEY, { expiresIn: '1d' });

    res.json({ token: `Bearer ${token}` });

  } catch (err) {
    console.error('Erro no login:', err);
    res.status(500).json({ error: 'Erro interno no servidor' });
  }
});

router.post('/login/simplificado', async (req, res) => {
  const rawCpf = req.body.Cpf || req.body.cpf;

  if (!rawCpf)
    return res.status(401).json({ error: 'Credenciais inválidas' });

  const Cpf = rawCpf.replace(/\D/g, '');

  const usuario = await Usuario.findOne({ where: { Cpf: Cpf } });

  if (!usuario) 
    return res.status(401).json({ error: 'Credenciais inválidas' });

  const IdUsuario = usuario.Id;
  const registro = await Login.findOne({ where: { IdUsuario } });

  if (!registro) 
    return res.status(401).json({ error: 'Credenciais inválidas' });

  registro.UltimoAcesso = new Date().toString()
  registro.save()
  
  const funcoes = await Funcao.findAll({
    where: { IdUsuario: IdUsuario }
  });

  let codigosFuncoes = funcoes.map(f => f.CodigoFuncao);

  if (codigosFuncoes.includes(ConstantesFuncoes.Administracao) ||
      codigosFuncoes.includes(ConstantesFuncoes.Gerencia)) {
    codigosFuncoes = [
      ConstantesFuncoes.CuidadosPessoais,
      ConstantesFuncoes.Culinaria,
      ConstantesFuncoes.Enfermagem,
      ConstantesFuncoes.Limpeza
    ]
  }

  const payload = {
    id: IdUsuario,
    idEmpresa: usuario.IdEmpresa,
    funcoes: codigosFuncoes
  };

  try {

    const token = jwt.sign(payload, process.env.SECRET_KEY, { expiresIn: '1d' });

    res.json({ token: `Bearer ${token}` });

  } catch (err) {
    console.error('Erro no login:', err);
    res.status(500).json({ error: 'Erro interno no servidor' });
  }
});

// Retorna usuario, filial e empresa com base em IdUsuario ou CPF
router.get('/info', auth, async (req, res) => {
  try {
    const { IdUsuario } = req.query;
    const rawCpf = req.query.cpf || req.query.Cpf;

    let usuario;
    if (IdUsuario) {
      usuario = await Usuario.findByPk(IdUsuario);
    } else if (rawCpf) {
      const cpf = rawCpf.replace(/\D/g, '');
      usuario = await Usuario.findOne({ where: { Cpf: cpf } });
    }

    if (!usuario) return res.status(404).json({ error: 'Usuário não encontrado' });

    const filial = await Filial.findOne({ where: { IdEmpresa: usuario.IdEmpresa } });
    let empresa = null;
    if (filial) {
      empresa = await Empresa.findByPk(filial.IdEmpresa);
    }

    res.json({ usuario, filial, empresa });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar informações' });
  }
});

module.exports = router;
