const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const controller = require('../controllers/funcao.controller');

const Funcoes = require('..//Constants/ConstsFuncoes')
const checkPermission = require('../middleware/checkPermission')

// Quem controla os cargos é a gerencia, deixei o get padrao sem verificacao porque filtra as funcoes do usuario autenticado
// Quando entrar na pagina no frontend, seria bom dar um Get e filtrar os botoes de acordo com as funcoes do usuario

router.get('/', auth,controller.getAll);
router.get('/:id', auth, checkPermission(Funcoes.Gerencia),controller.getById);
router.post('/', auth, checkPermission(Funcoes.Gerencia),controller.create);
router.put('/:id', auth, checkPermission(Funcoes.Gerencia),controller.update);
router.delete('/:id', auth, checkPermission(Funcoes.Gerencia),controller.delete);

module.exports = router;
