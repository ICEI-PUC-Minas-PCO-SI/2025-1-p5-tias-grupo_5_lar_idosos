const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const controller = require('../controllers/item.controller');

const Funcoes = require('..//Constants/ConstsFuncoes')
const checkPermission = require('../middleware/checkPermission')

router.get('/', auth, controller.getAll);
router.get('/categoria/:categoria/:idResidente/:isDashboard', auth, controller.getByCategoria);
router.get('/categoria/:categoria/:isDashboard', auth, controller.getByCategoria);
router.get('/:id', auth, controller.getById);
router.post('/', auth, checkPermission(Funcoes.Gerencia), controller.create);
router.put('/:id', auth, controller.update);
router.delete('/:id', auth, checkPermission(Funcoes.Gerencia), controller.delete);

module.exports = router;
