const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const controller = require('../controllers/filial.controller');

const Funcoes = require('..//Constants/ConstsFuncoes')
const checkPermission = require('../middleware/checkPermission')

// Cadastro de filiais é feito por gerencia

router.get('/', auth, checkPermission(Funcoes.Gerencia),controller.getAll);
router.get('/:id', auth, checkPermission(Funcoes.Gerencia),controller.getById);
router.get('/empresa/:id', auth, checkPermission(Funcoes.Gerencia),controller.getByEmpresaId);
router.post('/', auth, checkPermission(Funcoes.Gerencia),controller.create);
router.put('/:id', auth, checkPermission(Funcoes.Gerencia),controller.update);
router.delete('/:id', auth, checkPermission(Funcoes.Gerencia),controller.delete);

module.exports = router;
