const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const controller = require('../controllers/filial_usuario.controller');

const Funcoes = require('..//Constants/ConstsFuncoes')
const checkPermission = require('../middleware/checkPermission')

// Filiais e quem está nelas devem ser controlados pela gerencia

router.get('/', auth, checkPermission(Funcoes.Gerencia),controller.getAll);
router.get('/:id', auth, checkPermission(Funcoes.Gerencia),controller.getById);
router.post('/', auth, checkPermission(Funcoes.Gerencia),controller.create);
router.put('/:id', auth, checkPermission(Funcoes.Gerencia),controller.update);
router.delete('/:id', auth, checkPermission(Funcoes.Gerencia),controller.delete);

module.exports = router;
