function Header({ activeSection }) {
  return (
    <>
      {(activeSection === "dashboard") && <header className="header">
        <h1>Gerenciamento de Estoque</h1>
        {/* <div className="header-actions">
          <div className="header-search-container">
          <input type="text" placeholder="Buscar item..." className="header-search" />
          <i className="fas fa-search"></i>
          </div>
          <button onClick={openAddItemModal} className="header-add-button">
          <i className="fas fa-plus"></i> Adicionar Item
          </button>
          </div> */}
      </header>}
    </>
  );
}

export default Header;