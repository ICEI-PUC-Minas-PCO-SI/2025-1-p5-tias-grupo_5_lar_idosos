import { useState } from 'react';
import CategoriaItem from '../consts/CategoriaItem';

function Modal({ isOpen, onClose, onSave, onDelete, title, initialData, category }) {
  const [formData, setFormData] = useState(initialData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...formData,
      Nome: formData.Nome || '',
      Descricao: formData.Descricao || '',
      quantidadeNoEstoque: Number(formData.quantidadeNoEstoque) || 0,
      quantidadeMinima: Number(formData.quantidadeMinima) || 0,
      unidade: formData.unit || 'unidade',
      codigoBarras: formData.codigoBarras || `NEW-${Date.now()}`,
      tipo: formData.tipo || 'perishable',
      CategoriaItem: category,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>{title}</h3>
          <button onClick={onClose} className="modal-close-button">
            <i className="fas fa-times"></i>
          </button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="modal-field">
              <label htmlFor="itemCategory">Categoria</label>
              <select
                id="itemCategory"
                name="category"
                value={category}
                disabled
                className="modal-select"
              >
                <option value="1">Cozinha</option>
                <option value="2">Limpeza</option>
                <option value="3">Item Pessoal</option>
                <option value="4">Medico</option>
              </select>
            </div>
            <div className="modal-field">
              <label htmlFor="itemName">Nome do Item</label>
              <input
                type="text"
                id="itemName"
                name="Nome"
                value={formData.Nome || ''}
                onChange={handleChange}
                className="modal-input"
                placeholder="Ex: Leite em Pó"
              />
            </div>
            <div className="modal-field">
              <label htmlFor="itemDescription">Descrição</label>
              <input
                type="text"
                id="itemDescription"
                name="Descricao"
                value={formData.Descricao || ''}
                onChange={handleChange}
                rows={2}
                className="modal-input"
                placeholder="Descrição detalhada do item"
              />
            </div>
            <div className="modal-grid">
              <div className="modal-field">
                <label htmlFor="itemQuantity">Quantidade</label>
                <input
                  type="number"
                  id="itemQuantity"
                  name="quantidadeNoEstoque"
                  value={formData.quantidadeNoEstoque || ''}
                  onChange={handleChange}
                  className="modal-input"
                  placeholder="0"
                />
              </div>
              <div className="modal-field">
                <label htmlFor="itemMinQuantity">Quantidade Mínima</label>
                <input
                  type="number"
                  id="itemMinQuantity"
                  name="quantidadeMinima"
                  value={formData.quantidadeMinima || ''}
                  onChange={handleChange}
                  className="modal-input"
                  placeholder="0"
                />
              </div>
            </div>
            <div className="modal-grid">
              <div className="modal-field">
                <label htmlFor="itemUnit">Unidade</label>
                <select
                  id="itemUnit"
                  name="unidade"
                  value={formData.unidade || 'unit'}
                  onChange={handleChange}
                  className="modal-select"
                >
                  <option value="unit">Unidade</option>
                  <option value="box">Caixa</option>
                  <option value="pack">Pacote</option>
                  <option value="bottle">Garrafa</option>
                  <option value="bag">Saco</option>
                </select>
              </div>
              <div className="modal-field">
                <label htmlFor="itemBarcode">Código de Barras</label>
                <input
                  type="text"
                  id="itemBarcode"
                  name="codigoBarras"
                  value={formData.codigoBarras || ''}
                  onChange={handleChange}
                  className="modal-input"
                  placeholder="Código"
                />
              </div>
            </div>
            <div className="modal-field">
              <label htmlFor="itemType">Tipo</label>
              <select
                id="itemType"
                name="tipo"
                value={formData.tipo || 'perishable'}
                onChange={handleChange}
                className="modal-select"
              >
                <option value="perishable">Perecível</option>
                <option value="non-perishable">Não Perecível</option>
                <option value="chemical">Químico</option>
                <option value="essential">Essencial</option>
              </select>
            </div>
            <div className="modal-footer">
              {onDelete && (
                <button type="button" onClick={onDelete} className="modal-button delete">
                  <i className="fas fa-trash"></i> Excluir
                </button>
              )}
              <div className="modal-button-group">
                <button type="button" onClick={onClose} className="modal-button cancel">
                  Cancelar
                </button>
                <button type="submit" className="modal-button save">
                  Salvar
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Modal;