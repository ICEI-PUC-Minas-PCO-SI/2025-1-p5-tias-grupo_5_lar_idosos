import { useState, useEffect } from 'react';
import InventorySection from './InventorySection';
import useItems from '../hooks/useItems';
import { getCategoriaKeyByValue } from '../consts/CategoriaItem';

function PersonalSection() {
  const {
    items: apiItems,
    createItem,
    updateItem,
    deleteItem: apiDeleteItem,
  } = useItems(getCategoriaKeyByValue('RESIDENTES'));
  const [items, setItems] = useState([]);

  useEffect(() => {
    setItems(apiItems);
  }, [apiItems]);

  const addItem = (newItem) => {
    createItem(newItem);
  };

  const editItem = (updatedItem) => {
    updateItem(updatedItem.id, updatedItem);
  };

  const deleteItem = (id) => {
    apiDeleteItem(id);
  };

  return (
    <InventorySection
      title="Items Pessoais"
      items={items}
      category={getCategoriaKeyByValue('RESIDENTES')}
      addItem={addItem}
      editItem={editItem}
      deleteItem={deleteItem}
    />
  );
}

export default PersonalSection;
