function SuccessNotification({ message, show }) {
  return (
    <div className={`success-notification ${show ? 'show' : ''}`}>
      <i className="fas fa-check-circle"></i>
      <span>{message}</span>
    </div>
  );
}

export default SuccessNotification;