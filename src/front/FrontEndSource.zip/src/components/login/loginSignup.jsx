import { useState } from 'react';
import '../login/loginSignup.css';

function LoginSignup({ onLoginPassword, onLoginCpf, onLogin }) {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [cpf, setCpf] = useState('');
  const [mode, setMode] = useState('password');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const result =
      mode === 'password'
        ? await onLoginPassword({ login, password })
        : await onLoginCpf({ cpf });
    if (result?.success) {
      if (onLogin) {
        onLogin(mode === 'password' ? login : cpf);
      }
    } else {
      setError(result?.message || 'Credenciais inválidas');
    }
  };

  return (
    <div className="login-page">
      <div className="item-card" style={{ width: '100%', maxWidth: '350px' }}>
        <div className="item-card-header">
          <h3>Login</h3>
        </div>
        <div className="login-tabs">
          <div
            className={`login-tab ${mode === 'password' ? 'active' : ''}`}
            onClick={() => setMode('password')}
          >
            Login e Senha
          </div>
          <div
            className={`login-tab ${mode === 'cpf' ? 'active' : ''}`}
            onClick={() => setMode('cpf')}
          >
            Somente CPF
          </div>
        </div>
        <form onSubmit={handleSubmit} className="modal-body">
          {mode === 'password' && (
            <>
              <div className="modal-field">
                <label htmlFor="login">Login</label>
                <input
                  id="login"
                  type="text"
                  className="modal-input"
                  value={login}
                  onChange={(e) => setLogin(e.target.value)}
                  required
                />
              </div>
              <div className="modal-field">
                <label htmlFor="password">Senha</label>
                <input
                  id="password"
                  type="password"
                  className="modal-input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </>
          )}
          {mode === 'cpf' && (
            <div className="modal-field">
              <label htmlFor="cpf">CPF</label>
              <input
                id="cpf"
                type="text"
                className="modal-input"
                value={cpf}
                onChange={(e) => setCpf(e.target.value)}
                required
              />
            </div>
          )}
          {error && (
            <div className="modal-field" style={{ color: '#b91c1c' }}>
              {error}
            </div>
          )}
          <div className="item-actions">
            <button type="submit" className="item-action-button save" style={{ width: '100%' }}>
              Entrar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default LoginSignup;
