import { useUserSection } from './useUserSection';
import UserForm from './UserForm';

function UserSection({ title, users, category, addUser, editUser, deleteUser }) {
  const { isFormOpen, selectedUser, editedUser, openForm, closeForm, handleSave, handleDelete } =
    useUserSection(users, addUser, editUser, deleteUser);

  return (
    <div className="section-content">
      <div className="section-header">
        <h2>{title}</h2>
        <div className="section-actions">
          <button onClick={() => openForm()} className="section-button add">
            <i className="fas fa-plus"></i> Adicionar Usuário
          </button>
        </div>
      </div>
      {isFormOpen && (
        <UserForm
          user={editedUser}
          onSave={handleSave}
          onCancel={closeForm}
          onDelete={handleDelete}
        />
      )}
      <div className="inventory-grid">
        {users.map((user) => (
          <div key={user.id} className="item-card">
            <div className="item-card-header">
              <div>
                <h3>{user.name}</h3>
                <p>CPF: {user.cpf}</p>
              </div>
            </div>
            <div className="item-actions">
              <button
                onClick={() => openForm(user)}
                className="item-action-button edit"
              >
                <i className="fas fa-edit"></i> Editar
              </button>
              <button
                onClick={() => handleDelete(user.id)}
                className="item-action-button delete"
              >
                <i className="fas fa-trash"></i> Excluir
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default UserSection;