import { useState } from 'react';

export function useUserSection(users, addUser, editUser, deleteUser) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editedUser, setEditedUser] = useState(null);

  const openForm = (user = null) => {
    setSelectedUser(user);
    setEditedUser(user ? user : null);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setSelectedUser(null);
    setEditedUser(null);
  };

  const handleSave = (userData) => {
    if (userData.id) {
      editUser(userData);
    } else {
      addUser(userData);
    }
    closeForm();
  };

  const handleDelete = (id) => {
    deleteUser(id);
    closeForm();
  };

  return {
    isFormOpen,
    selectedUser,
    editedUser,
    openForm,
    closeForm,
    handleSave,
    handleDelete,
  };
}