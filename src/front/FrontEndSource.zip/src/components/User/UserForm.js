import { useEffect, useState } from 'react';

function UserForm({ user, onSave, onCancel, onDelete }) {
  const [formData, setFormData] = useState({
    id: user?.id,
    cpf: user?.cpf || '',
    password: user?.password || '',
    name: user?.name || '',
    changeDate: user?.changeDate || new Date().toISOString().slice(0, 16),
  });

  useEffect(() => {   
    setFormData({
      id: user?.id,
      cpf: user?.cpf || '',
      password: user?.password || '',
      name: user?.name || '',
      changeDate: user?.changeDate || new Date().toISOString().slice(0, 16),
    })
  }
  , [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      id: formData.id,
      cpf: formData.cpf,
      password: formData.password,
      name: formData.name,
      changeDate: formData.changeDate || new Date().toISOString().slice(0, 19).replace('T', ' '),
    });
  };

  return (
    <div className="item-card" style={{ marginBottom: '1.5rem' }}>
      <div className="item-card-header">
        <h3>{user ? 'Editar Usuário' : 'Adicionar Novo Usuário'}</h3>
      </div>
      <form onSubmit={handleSubmit} className="modal-body">
        <div className="modal-field">
          <label htmlFor="userCPF">CPF</label>
          <input
            type="text"
            id="userCPF"
            name="cpf"
            value={formData.cpf}
            onChange={handleChange}
            className="modal-input"
            placeholder="Ex: 123.456.789-00"
            maxLength="14"
            required
          />
        </div>
        <div className="modal-field">
          <label htmlFor="userPassword">Senha</label>
          <input
            type="password"
            id="userPassword"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="modal-input"
            placeholder="Digite a senha"
            required
          />
        </div>
        <div className="modal-field">
          <label htmlFor="userName">Nome</label>
          <input
            type="text"
            id="userName"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="modal-input"
            placeholder="Ex: João Silva"
            required
          />
        </div>
        <div className="modal-field">
          <label htmlFor="userChangeDate">Data de Alteração</label>
          <input
            type="datetime-local"
            id="userChangeDate"
            name="changeDate"
            value={formData.changeDate}
            onChange={handleChange}
            className="modal-input"
            required
          />
        </div>
        <div className="item-actions">
          {onDelete && (
            <button
              type="button"
              onClick={() => onDelete(formData.id)}
              className="item-action-button delete"
            >
              <i className="fas fa-trash"></i> Excluir
            </button>
          )}
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={onCancel}
              className="item-action-button cancel"
              style={{ backgroundColor: '#e5e7eb', color: '#374151' }}
            >
              Cancelar
            </button>
            <button type="submit" className="item-action-button save">
              Salvar
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default UserForm;