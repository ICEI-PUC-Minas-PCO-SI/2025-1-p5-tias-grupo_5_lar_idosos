import { useState } from 'react';
import ItemCard from './ItemCard';
import Modal from './Modal';

function InventorySection({ title, items, category, addItem, editItem, deleteItem }) {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const openAddModal = () => setIsAddModalOpen(true);
  const openEditModal = (item) => {
    setSelectedItem(item);
    setIsEditModalOpen(true);
  };
  const closeModal = () => {
    setIsAddModalOpen(false);
    setIsEditModalOpen(false);
    setSelectedItem(null);
  };

  return (
    <div className="section-content">
      <div className="section-header">
        <h2>{title}</h2>
        <div className="section-actions">
          <button onClick={openAddModal} className="section-button add">
            <i className="fas fa-plus"></i> Adicionar
          </button>
        </div>
      </div>
      <div className="inventory-grid">
        {items.map((item) => (
          <ItemCard
            key={item.barcode}
            item={item}
            category={category}
            editItem={openEditModal}
            deleteItem={deleteItem}
          />
        ))}
      </div>
      {isAddModalOpen && (
        <Modal
          isOpen={isAddModalOpen}
          onClose={closeModal}
          onSave={(item) => {
            addItem({ ...item, barcode: `NEW-${Date.now()}` }, category);
            closeModal();
          }}
          title="Adicionar Novo Item"
          initialData={{}}
          category={category}
        />
      )}
      {isEditModalOpen && selectedItem && (
        <Modal
          isOpen={isEditModalOpen}
          onClose={closeModal}
          onSave={(item) => {
            editItem(item, category);
            closeModal();
          }}
          onDelete={() => {
            deleteItem(selectedItem.Id);
            closeModal();
          }}
          title="Editar Item"
          initialData={selectedItem}
          category={category}
        />
      )}
    </div>
  );
}

export default InventorySection;