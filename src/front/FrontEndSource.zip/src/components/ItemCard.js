import CategoriaItem from "../consts/CategoriaItem";
import UnidadeMedida from "../consts/UnidadeMedida";

function ItemCard({ item, category, editItem, deleteItem }) {
  const stockPercentage = Math.min((item.quantidadeNoEstoque / item.quantidadeMinima) * 100, 100);
  const isLowStock = item.quantidadeNoEstoque < item.quantidadeMinima;
  const isCriticalStock = item.quantidadeNoEstoque <= item.quantidadeMinima / 2;

  return (
    <div
      className={`item-card ${isCriticalStock ? 'critical-stock' : isLowStock ? 'low-stock' : ''}`}
    >
      <div className="item-card-header">
        <div>
          <h3>{item.Nome}</h3>
          <p>{item.Descricao}</p>
        </div>
        <span className={`item-type ${item.tipo}`}>{getItemTypeLabel(item.tipo)}</span>
      </div>
      <div className="item-stock">
        <div className="item-stock-info">
          <span>Estoque: {item.quantidadeNoEstoque}</span>
          <span>Mínimo: {item.quantidadeMinima}</span>
        </div>
        <div className="item-stock-bar">
          <div
            className="item-stock-progress"
            style={{ width: `${stockPercentage}%` }}
          ></div>
        </div>
      </div>
      <div className="item-details">
        <div>
          <i className="fas fa-box-open"></i> <span>Unidade: {UnidadeMedida[item.unidade]}</span>
        </div>
        <div>
          <i className="fas fa-barcode"></i> <span>{item.codigoBarras}</span>
        </div>
      </div>
      <div className="item-actions">
        <button onClick={() => editItem(item, CategoriaItem[item.category])} className="item-action-button edit">
          <i className="fas fa-edit"></i> Editar
        </button>
        <button onClick={() => deleteItem(item.Id)} className="item-action-button delete">
          <i className="fas fa-trash"></i> Excluir
        </button>
      </div>
    </div>
  );

  function getItemTypeLabel(type) {
    return type === 'perishable'
      ? 'Perecível'
      : type === 'non-perishable'
      ? 'Não Perecível'
      : type === 'chemical'
      ? 'Químico'
      : 'Essencial';
  }
}

export default ItemCard;