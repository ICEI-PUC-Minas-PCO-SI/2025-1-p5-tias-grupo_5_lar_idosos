import { AppDataContext } from "../contexts/AppDataContext";
import { useContext } from "react";

function Sidebar({ isCollapsed, isMobile, toggleSidebar, showSection, onLogout }) {
    const { filial, usuario, empresa } = useContext(AppDataContext);


  return (
    <div className={`sidebar ${isCollapsed ? 'collapsed' : ''} ${isMobile && !isCollapsed ? 'open' : ''}`}>
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <i className="fas fa-home"></i>
        </div>
        {!isCollapsed && <span className="logo-text">{empresa?.razao_social}</span>}
      </div>

      <div className="sidebar-user">
        <div className="sidebar-user-avatar">
          <i className="fas fa-user"></i>
        </div>
        {!isCollapsed && (
          <div className="sidebar-text">
            <div>{usuario.Nome}</div>
            <div className="sidebar-email">{usuario?.Email}</div>
          </div>
        )}
      </div>

      <nav className="sidebar-nav">
        <div className="sidebar-nav-group">
          {!isCollapsed && <div className="sidebar-nav-title">Menu Principal</div>}
          <button onClick={() => showSection('dashboard')} className="sidebar-nav-item">
            <i className="fas fa-tachometer-alt"></i>
            {!isCollapsed && <span>Dashboard</span>}
          </button>
        </div>

        <div className="sidebar-nav-group">
          {!isCollapsed && <div className="sidebar-nav-title">Estoque</div>}
          <button onClick={() => showSection('kitchen')} className="sidebar-nav-item">
            <i className="fas fa-utensils"></i>
            {!isCollapsed && <span>Cozinha</span>}
          </button>
          <button onClick={() => showSection('cleaning')} className="sidebar-nav-item">
            <i className="fas fa-broom"></i>
            {!isCollapsed && <span>Limpeza</span>}
          </button>
          <button onClick={() => showSection('residents')} className="sidebar-nav-item">
            <i className="fas fa-user-tag"></i>
            {!isCollapsed && <span>Residentes</span>}
          </button>
        </div>

        <div className="sidebar-nav-group">
          {!isCollapsed && <div className="sidebar-nav-title">Administrador</div>}
          <button onClick={() => showSection('users')} className="sidebar-nav-item">
            <i className="fas fa-exclamation-triangle"></i>
            {!isCollapsed && <span>Usuários</span>}
          </button>
        </div>
      </nav>

      <div className="sidebar-footer">
        <button onClick={onLogout} className="sidebar-nav-item" style={{ marginBottom: '8px' }}>
          <i className="fas fa-sign-out-alt"></i>
          {!isCollapsed && <span>Sair</span>}
        </button>
        <button onClick={toggleSidebar} className="sidebar-nav-item">
          <i className={`fas ${isCollapsed ? 'fa-chevron-right' : 'fa-chevron-left'}`}></i>
          {!isCollapsed && <span>Recolher Menu</span>}
        </button>
      </div>
    </div>
  );
}

export default Sidebar;