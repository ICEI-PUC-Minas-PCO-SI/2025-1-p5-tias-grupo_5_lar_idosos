import { useState } from 'react';
import ResidentCard from './ResidentCard';
import ItemCard from './ItemCard';
import ResidentModal from './ResidentModal';
import Modal from './Modal';
import useResidents from '../hooks/useResidents';
import useItems from '../hooks/useItems';
import { getCategoriaKeyByValue } from '../consts/CategoriaItem';

function ResidentSection({ title, category }) {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedResident, setSelectedResident] = useState(null);
  const [selectedResidentDetails, setSelectedResidentDetails] = useState(null);
  const [isItemAddModalOpen, setIsItemAddModalOpen] = useState(false);
  const [isItemEditModalOpen, setIsItemEditModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [itemModalCategory, setItemModalCategory] = useState(null);
  const {
    items: personalItems,
    createItem: createPersonalItem,
    updateItem: updatePersonalItem,
    deleteItem: deletePersonalItem,
  } = useItems(
    getCategoriaKeyByValue('PESSOAL'),
    selectedResidentDetails?.Id
  );
  const {
    items: medicalItems,
    createItem: createMedicalItem,
    updateItem: updateMedicalItem,
    deleteItem: deleteMedicalItem,
  } = useItems(
    getCategoriaKeyByValue('MEDICOS'),
    selectedResidentDetails?.Id
  );
  const {
    residents,
    createResident,
    updateResident,
    deleteResident,
  } = useResidents();

  const openAddModal = () => setIsAddModalOpen(true);
  const openEditModal = (resident) => {
    setSelectedResident(resident);
    setIsEditModalOpen(true);
  };
  const closeModal = () => {
    setIsAddModalOpen(false);
    setIsEditModalOpen(false);
    setSelectedResident(null);
  };

  const viewDetails = (residentId) => () => {
    const resident = residents.find((r) => r.Id === residentId);
    if (resident) {
      setSelectedResidentDetails(resident);
    }
  }

  const cleaningSelectedResidentDetails = () => {
    setSelectedResidentDetails(null);
  };

  const openAddItemModal = (category) => {
    setItemModalCategory(category);
    setIsItemAddModalOpen(true);
  };

  const openEditItemModal = (item, category) => {
    setSelectedItem(item);
    setItemModalCategory(category);
    setIsItemEditModalOpen(true);
  };

  const closeItemModal = () => {
    setIsItemAddModalOpen(false);
    setIsItemEditModalOpen(false);
    setSelectedItem(null);
    setItemModalCategory(null);
  };

  const addItem = (item, category) => {
    if (category === getCategoriaKeyByValue('PESSOAL')) {
      createPersonalItem({ ...item, IdResidente: selectedResidentDetails?.Id });
    } else if (category === getCategoriaKeyByValue('MEDICOS')) {
      createMedicalItem({ ...item, IdResidente: selectedResidentDetails?.Id });
    }
  };

  const editItem = (item, category) => {
    if (category === getCategoriaKeyByValue('PESSOAL')) {
      updatePersonalItem(item.Id, item);
    } else if (category === getCategoriaKeyByValue('MEDICOS')) {
      updateMedicalItem(item.Id, item);
    }
  };

  const deleteItem = (id, category) => {
    if (category === getCategoriaKeyByValue('PESSOAL')) {
      deletePersonalItem(id);
    } else if (category === getCategoriaKeyByValue('MEDICOS')) {
      deleteMedicalItem(id);
    }
  };

  return (
    <div className="section-content">
      {selectedResidentDetails ? 
        <>
          <div className="section-header">
            <h2 onClick={() => cleaningSelectedResidentDetails()}
              style={{ cursor: 'pointer' }}
            >
              {`${title} > ${selectedResidentDetails?.Nome} > Items Pessoais`}
            </h2>
            <div className="section-actions">
              <button onClick={() => openAddItemModal(getCategoriaKeyByValue('PESSOAL'))} className="section-button add">
                <i className="fas fa-plus"></i> Adicionar
              </button>
            </div>
          </div>
          <div className="inventory-grid">
            {personalItems.map((item) => (
              <ItemCard
                key={item.barcode}
                item={item}
                category={getCategoriaKeyByValue('PESSOAL')}
                editItem={(i) => openEditItemModal(i, getCategoriaKeyByValue('PESSOAL'))}
                deleteItem={(id) => deleteItem(id, getCategoriaKeyByValue('PESSOAL'))}
              />
            ))}
          </div>
          <div className="section-header" style={{ paddingTop: '40px' }}>
            <h2 onClick={() => cleaningSelectedResidentDetails()}
              style={{ cursor: 'pointer' }}
            >
              {`${title} > ${selectedResidentDetails?.Nome} > Items Medicos`}
            </h2>
            <div className="section-actions">
              <button onClick={() => openAddItemModal(getCategoriaKeyByValue('MEDICOS'))} className="section-button add">
                <i className="fas fa-plus"></i> Adicionar
              </button>
            </div>
          </div>
          <div className="inventory-grid">
            {medicalItems.map((item) => (
              <ItemCard
                key={item.barcode}
                item={item}
                category={getCategoriaKeyByValue('MEDICOS')}
                editItem={(i) => openEditItemModal(i, getCategoriaKeyByValue('MEDICOS'))}
                deleteItem={(id) => deleteItem(id, getCategoriaKeyByValue('MEDICOS'))}
              />
            ))}
          </div>
        </> 
        :
        <>
          <div className="section-header">
            <h2>{title}</h2>
            <div className="section-actions">
              <button onClick={openAddModal} className="section-button add">
                <i className="fas fa-plus"></i> Adicionar Morador
              </button>
            </div>
          </div>
          <div className="inventory-grid">
            {residents.map((resident) => (
              <ResidentCard
                key={resident.Id}
                resident={resident}
                category={category}
                editResident={openEditModal}
                viewDetails={viewDetails(resident.Id)}
              />
            ))}
          </div>
        </>
      }

      {isAddModalOpen && (
        <ResidentModal
          isOpen={isAddModalOpen}
          onClose={closeModal}
          onSave={(resident) => {
            createResident(resident);
            closeModal();
          }}
          title="Adicionar Novo Morador"
          initialData={{}}
          category={category}
        />
      )}
      {isEditModalOpen && selectedResident && (
        <ResidentModal
          isOpen={isEditModalOpen}
          onClose={closeModal}
          onSave={(resident) => {
            updateResident(resident.Id, resident);
            closeModal();
          }}
          onDelete={() => {
            deleteResident(selectedResident.Id);
            closeModal();
          }}
          title="Editar Morador"
          initialData={selectedResident}
          category={category}
        />
      )}
      {isItemAddModalOpen && (
        <Modal
          isOpen={isItemAddModalOpen}
          onClose={closeItemModal}
          onSave={(item) => {
            addItem(item, itemModalCategory);
            closeItemModal();
          }}
          title="Adicionar Item"
          initialData={{}}
          category={itemModalCategory}
        />
      )}
      {isItemEditModalOpen && selectedItem && (
        <Modal
          isOpen={isItemEditModalOpen}
          onClose={closeItemModal}
          onSave={(item) => {
            editItem(item, itemModalCategory);
            closeItemModal();
          }}
          onDelete={() => {
            deleteItem(selectedItem.Id, itemModalCategory);
            closeItemModal();
          }}
          title="Editar Item"
          initialData={selectedItem}
          category={itemModalCategory}
        />
      )}
    </div>
  );
}

export default ResidentSection;

