import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import useItems from '../hooks/useItems';
import { getCategoriaKeyByValue } from '../consts/CategoriaItem';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

function Dashboard() {
  const { items: kitchenItems } = useItems(getCategoriaKeyByValue('COZINHA'), null, true);
  const { items: cleaningItems } = useItems(getCategoriaKeyByValue('LIMPEZA'), null, true);
  const { items: personalItems } = useItems(getCategoriaKeyByValue('PESSOAL'), null, true);
  const { items: medicalItems } = useItems(getCategoriaKeyByValue('MEDICOS'), null, true);

  const kitchenTotal = kitchenItems.reduce(
    (sum, i) => sum + (i.quantidadeNoEstoque || 0),
    0
  );
  const cleaningTotal = cleaningItems.reduce(
    (sum, i) => sum + (i.quantidadeNoEstoque || 0),
    0
  );
  const personalTotal = personalItems.reduce(
    (sum, i) => sum + (i.quantidadeNoEstoque || 0),
    0
  );
  const medicalTotal = medicalItems.reduce(
    (sum, i) => sum + (i.quantidadeNoEstoque || 0),
    0
  );

  const kitchenLow = kitchenItems.filter(
    (i) => i.quantidadeNoEstoque < i.quantidadeMinima
  ).length;
  const cleaningLow = cleaningItems.filter(
    (i) => i.quantidadeNoEstoque < i.quantidadeMinima
  ).length;
  const personalLow = personalItems.filter(
    (i) => i.quantidadeNoEstoque < i.quantidadeMinima
  ).length;
  const medicalLow = medicalItems.filter(
    (i) => i.quantidadeNoEstoque < i.quantidadeMinima
  ).length;

  const data = {
    labels: ['Cozinha', 'Limpeza', 'Pessoais', 'Médicos'],
    datasets: [
      {
        label: 'Quantidade total de itens',
        data: [kitchenTotal, cleaningTotal, personalTotal, medicalTotal],
        backgroundColor: ['#3B82F6', '#10B981', '#8B5CF6', '#FBBF24'],
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="section-content">
      <div className="dashboard-grid">
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <div className="dashboard-icon kitchen">
              <i className="fas fa-utensils"></i>
            </div>
            <div>
              <h3>Itens de Cozinha</h3>
              <p>{kitchenTotal}</p>
            </div>
          </div>
          <div className="dashboard-progress">
            <div className="dashboard-progress-info">
              <span>{kitchenLow} itens com estoque baixo</span>
              <span>
                {(
                  ((kitchenLow / (kitchenItems.length || 1)) * 100) 
                ).toFixed(1)}%
              </span>
            </div>
            <div className="dashboard-progress-bar">
              <div
                className="dashboard-progress-fill"
                style={{
                  width: `${100 - ((kitchenLow / (kitchenItems.length || 1)) * 100)}%`
                }}
              ></div>
            </div>
          </div>
        </div>
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <div className="dashboard-icon cleaning">
              <i className="fas fa-broom"></i>
            </div>
            <div>
              <h3>Materiais de Limpeza</h3>
              <p>{cleaningTotal}</p>
            </div>
          </div>
          <div className="dashboard-progress">
            <div className="dashboard-progress-info">
              <span>{cleaningLow} itens com estoque baixo</span>
              <span>
                {(
                  ((cleaningLow / (cleaningItems.length || 1)) * 100)
                ).toFixed(1)}%
              </span>
            </div>
            <div className="dashboard-progress-bar">
              <div
                className="dashboard-progress-fill"
                style={{
                  width: `${100 - ((cleaningLow / (cleaningItems.length || 1)) * 100)}%`
                }}
              ></div>
            </div>
          </div>
        </div>
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <div className="dashboard-icon personal">
              <i className="fas fa-user"></i>
            </div>
            <div>
              <h3>Itens Pessoais</h3>
              <p>{personalTotal}</p>
            </div>
          </div>
          <div className="dashboard-progress">
            <div className="dashboard-progress-info">
              <span>{personalLow} itens com estoque baixo</span>
              <span>
                {(
                  ((personalLow / (personalItems.length || 1)) * 100)
                ).toFixed(1)}%
              </span>
            </div>
            <div className="dashboard-progress-bar">
              <div
                className="dashboard-progress-fill"
                style={{
                  width: `${100 - ((personalLow / (personalItems.length || 1)) * 100)}%`
                }}
              ></div>
            </div>
          </div>
        </div>
        <div className="dashboard-card">
          <div className="dashboard-card-header">
            <div className="dashboard-icon medical">
              <i className="fas fa-user-md"></i>
            </div>
            <div>
              <h3>Itens Médicos</h3>
              <p>{medicalTotal}</p>
            </div>
          </div>
          <div className="dashboard-progress">
            <div className="dashboard-progress-info">
              <span>{medicalLow} itens com estoque baixo</span>
              <span>
                {(
                  ((medicalLow / (medicalItems.length || 1)) * 100)
                ).toFixed(1)}%
              </span>
            </div>
            <div className="dashboard-progress-bar">
              <div
                className="dashboard-progress-fill"
                style={{
                  width: `${100 - ((medicalLow / (medicalItems.length || 1)) * 100)}%`
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>
      <div className="chart-container">
        <Bar data={data} options={options} />
      </div>
    </div>
  );
}

export default Dashboard;