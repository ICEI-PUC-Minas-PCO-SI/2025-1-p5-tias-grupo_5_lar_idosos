import { useState } from 'react';

function ResidentModal({ isOpen, onClose, onSave, onDelete, title, initialData, category }) {
  const [formData, setFormData] = useState({ ...initialData, category: 'residents' });
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      Id: formData.Id || null,
      Nome: formData.Nome || '',
      Cpf: formData.Cpf || '',
      DataNascimento: formData.DataNascimento || '',
      Observacoes: formData.Observacoes || '',
      DataEntrada: formData.DataEntrada || '',
    });
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>{title}</h3>
          <button onClick={onClose} className="modal-close-button">
            <i className="fas fa-times"></i>
          </button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="modal-field">
              <label htmlFor="residentCategory">Categoria</label>
              <select
                id="residentCategory"
                name="category"
                value={category}
                disabled
                className="modal-select"
              >
                <option value="residents">Moradores</option>
              </select>
            </div>
            <div className="modal-field">
              <label htmlFor="residentName">Nome do Morador</label>
              <input
                type="text"
                id="residentName"
                name="Nome"
                value={formData.Nome || ''}
                onChange={handleChange}
                className="modal-input"
                placeholder="Ex: João Silva"
              />
            </div>
            <div className="modal-field">
              <label htmlFor="residentCpf">CPF</label>
              <input
                type="text"
                id="residentCpf"
                name="Cpf"
                value={formData.Cpf || ''}
                onChange={handleChange}
                className="modal-input"
                placeholder="12345678901"
              />
            </div>
            <div className="modal-field">
              <label htmlFor="residentBirth">Data de Nascimento</label>
              <input
                type="date"
                id="residentBirth"
                name="DataNascimento"
                value={formData.DataNascimento || ''}
                onChange={handleChange}
                className="modal-input"
              />
            </div>
            <div className="modal-field">
              <label htmlFor="residentEntry">Data de Entrada</label>
              <input
                type="date"
                id="residentEntry"
                name="DataEntrada"
                value={formData.DataEntrada?.split('T')[0] || formData.DataEntrada}
                onChange={handleChange}
                className="modal-input"
              />
            </div>
            <div className="modal-field">
              <label htmlFor="residentObservacoes">Observações</label>
              <textarea
                id="residentObservacoes"
                name="Observacoes"
                value={formData.Observacoes || ''}
                onChange={handleChange}
                rows={2}
                className="modal-input"
                placeholder="Informações adicionais"
              />
            </div>
            <div className="modal-footer">
              {onDelete && (
                <button type="button" onClick={onDelete} className="modal-button delete">
                  <i className="fas fa-trash"></i> Excluir
                </button>
              )}
              <div className="modal-button-group">
                <button type="button" onClick={onClose} className="modal-button cancel">
                  Cancelar
                </button>
                <button type="submit" className="modal-button save">
                  Salvar
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ResidentModal;
