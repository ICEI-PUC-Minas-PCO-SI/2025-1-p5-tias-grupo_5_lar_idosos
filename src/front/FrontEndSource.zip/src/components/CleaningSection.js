import { useState, useEffect } from 'react';
import InventorySection from './InventorySection';
import useItems from '../hooks/useItems';
import { getCategoriaKeyByValue } from '../consts/CategoriaItem';

function CleaningSection() {
  const {
    items: apiItems,
    createItem,
    updateItem,
    deleteItem: apiDeleteItem,
  } = useItems(getCategoriaKeyByValue('LIMPEZA'));
  const [items, setItems] = useState([]);

  useEffect(() => {
    setItems(apiItems);
  }, [apiItems]);

  const addItem = (newItem) => {
    createItem(newItem);
  };

  const editItem = (updatedItem) => {
    updateItem(updatedItem.id, updatedItem);
  };

  const deleteItem = (id) => {
    apiDeleteItem(id);
  };

  return (
    <InventorySection
      title="Materiais de Limpeza"
      items={items}
      category={getCategoriaKeyByValue('LIMPEZA')}
      addItem={addItem}
      editItem={editItem}
      deleteItem={deleteItem}
    />
  );
}

export default CleaningSection;
