function ResidentCard({ resident, category, editResident, viewDetails }) {
  const age = resident.DataNascimento
    ? new Date().getFullYear() - new Date(resident.DataNascimento).getFullYear()
    : '';

  return (
    <div className="item-card">
      <div className="item-card-header">
        <div>
          <h3>{resident.Nome}</h3>
          <p>{resident.Observacoes || 'Morador do Asilo Feliz'}</p>
        </div>
      </div>
      <div className="item-stock">
        <div className="item-stock-info">
          <span>CPF: {resident.Cpf}</span>
          <span>Idade: {age}</span>
        </div>
      </div>
      <div className="item-details">
        <div>
          <i className="fas fa-calendar-alt"></i>{' '}
          <span>Entrada: {resident.DataEntrada?.split('T')[0] || resident.DataEntrada}</span>
        </div>
      </div>
      <div className="item-actions">
        <button onClick={() => editResident(resident, category)} className="item-action-button edit">
          <i className="fas fa-edit"></i> Editar
        </button>
        <button onClick={() => viewDetails(resident, category)} className="item-action-button view">
          <i className="fas fa-eye"></i> Detalhes
        </button>
      </div>
    </div>
  );
}

export default ResidentCard;
