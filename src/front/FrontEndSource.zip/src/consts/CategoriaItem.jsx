const CategoriaItem = {
    1: 'COZINHA',
    2: 'LIMPEZA',
    3: 'PESSOAL',
    4: 'MEDICOS'
};

export function getCategoriaKeyByValue(value) {
    return Number(
        Object.keys(CategoriaItem).find((key) => CategoriaItem[key] === value)
    );
}


Object.freeze(CategoriaItem);
export default CategoriaItem;