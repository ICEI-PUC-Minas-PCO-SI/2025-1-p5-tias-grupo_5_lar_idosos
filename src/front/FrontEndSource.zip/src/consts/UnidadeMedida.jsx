const UnidadeMedida = {
    unit: 'Unidade',
    box: 'Caixa',
    pack: 'Pacote',
    bottle: 'Garrafa',
    bag: 'Saco',
};

Object.freeze(UnidadeMedida);
export default UnidadeMedida;
