import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import LoginSignup from './components/login/loginSignup';
import useAuth from './hooks/useAuth';
import { AppDataProvider } from './contexts/AppDataContext';

function Root() {
  const { token, loginWithPassword, loginWithCpf, logout } = useAuth();
  const [login, setLogin] = useState(() => localStorage.getItem('login') || '');

  const handleLoggedIn = (userLogin) => {
    setLogin(userLogin);
    localStorage.setItem('login', userLogin);
  };

  const handleLogout = () => {
    logout();
    setLogin('');
    localStorage.removeItem('login');
  };

  if (!token) {
    return (
      <LoginSignup
        onLoginPassword={loginWithPassword}
        onLoginCpf={loginWithCpf}
        onLogin={handleLoggedIn}
      />
    );
  }
  return (
    <AppDataProvider initialUsuario={login}>
      <App onLogout={handleLogout} />
    </AppDataProvider>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Root />);

