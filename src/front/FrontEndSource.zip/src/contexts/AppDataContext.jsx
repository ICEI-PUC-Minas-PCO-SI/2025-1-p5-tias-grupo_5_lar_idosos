import React, { createContext, useState, useEffect } from 'react';

export const AppDataContext = createContext({
  filial: null,
  setFilial: () => { },
  usuario: null,
  setUsuario: () => { },
  empresa: null,
  setEmpresa: () => { },
});

export function AppDataProvider({ children, initialFilial = null, initialUsuario = null }) {
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';
  const token = localStorage.getItem('bearerToken');

  const [filial, setFilial] = useState(initialFilial);
  const [usuario, setUsuario] = useState(initialUsuario);
  const [empresa, setEmpresa] = useState(null);

  console.log(filial, usuario, empresa);

  useEffect(() => {
    async function fetchInitialData() {
      if (!initialUsuario) return;

      try {
        const cleaned = initialUsuario.replace(/[^\d]/g, '');
        const isCpf = /^\d{11}$/.test(cleaned);
        const query = isCpf
          ? `?cpf=${initialUsuario}`
          : `?IdUsuario=${initialUsuario}`;

        const infoRes = await fetch(`${baseUrl}/api/auth/info${query}`, {
          headers: token ? { Authorization: `${token}` } : {},
        });

        if (!infoRes.ok) throw new Error('Erro ao buscar dados iniciais');

        const { usuario: userData, filial: filialData, empresa: empresaData } =
          await infoRes.json();

        setUsuario(userData);
        setFilial(filialData);
        setEmpresa(empresaData);
      } catch (err) {
        console.error('Erro ao carregar dados iniciais:', err);
      }
    }

    fetchInitialData();
  }, [initialUsuario, baseUrl, token]);

  return (
    <AppDataContext.Provider value={{ filial, setFilial, usuario, setUsuario, empresa, setEmpresa }}>
      {children}
    </AppDataContext.Provider>
  );
}
