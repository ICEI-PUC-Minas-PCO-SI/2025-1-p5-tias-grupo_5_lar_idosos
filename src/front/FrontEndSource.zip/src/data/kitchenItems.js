const kitchenItems = [
  {
    name: 'Leite em Pó',
    description: 'Alimento',
    quantity: 5,
    minQuantity: 15,
    unit: 'box',
    barcode: 'KIT-001',
    type: 'perishable',
  },
  {
    name: 'Arroz',
    description: 'Alimento',
    quantity: 12,
    minQuantity: 10,
    unit: 'bag',
    barcode: 'KIT-002',
    type: 'non-perishable',
  },
  {
    name: 'Café',
    description: 'Alimento',
    quantity: 8,
    minQuantity: 10,
    unit: 'pack',
    barcode: 'KIT-003',
    type: 'non-perishable',
  },
  {
    name: 'Açúcar',
    description: 'Alimento',
    quantity: 15,
    minQuantity: 8,
    unit: 'bag',
    barcode: 'KIT-004',
    type: 'non-perishable',
  },
];

export default kitchenItems;