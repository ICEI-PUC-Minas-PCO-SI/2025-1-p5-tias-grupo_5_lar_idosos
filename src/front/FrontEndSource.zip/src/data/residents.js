const residents = [
  { id: 1, name: 'João Silva', age: 78, room: '101', healthCondition: 85, admissionDate: '2023-06-15', status: 'active' },
  { id: 2, name: 'Maria Oliveira', age: 82, room: '102', healthCondition: 30, admissionDate: '2022-09-10', status: 'observation' },
  { id: 3, name: 'Carlos Pereira', age: 70, room: '103', healthCondition: 15, admissionDate: '2024-01-20', status: 'inactive' },
];

export default residents;