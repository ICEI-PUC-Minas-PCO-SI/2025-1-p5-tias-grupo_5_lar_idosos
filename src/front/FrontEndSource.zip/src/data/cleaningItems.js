const cleaningItems = [
  {
    name: 'Desinfetante',
    description: 'Limpeza',
    quantity: 3,
    minQuantity: 8,
    unit: 'bottle',
    barcode: 'LIM-001',
    type: 'chemical',
  },
  {
    name: 'Sabão em Pó',
    description: 'Limpeza',
    quantity: 10,
    minQuantity: 5,
    unit: 'box',
    barcode: 'LIM-002',
    type: 'chemical',
  },
  {
    name: 'Álcool 70%',
    description: 'Limpeza',
    quantity: 12,
    minQuantity: 6,
    unit: 'bottle',
    barcode: 'LIM-003',
    type: 'chemical',
  },
  {
    name: 'Vassoura',
    description: 'Limpeza',
    quantity: 7,
    minQuantity: 4,
    unit: 'unit',
    barcode: 'LIM-004',
    type: 'essential',
  },
];

export default cleaningItems;