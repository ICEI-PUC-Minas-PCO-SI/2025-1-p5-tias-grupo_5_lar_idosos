import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import UserSection from './components/User/UserSection';
import useUsers from './hooks/useUsers';
import ResidentSection from './components/ResidentSection';
import SuccessNotification from './components/SuccessNotification';
import KitchenSection from './components/KitchenSection';
import CleaningSection from './components/CleaningSection';
import PersonalSection from './components/PersonalSection';
import './App.css';

function App({ onLogout }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [activeSection, setActiveSection] = useState('dashboard');
  const { users, createUser, updateUser, deleteUser: deleteUserFn } = useUsers();
  const [notification, setNotification] = useState({ message: '', show: false });

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setIsSidebarCollapsed(true);
      } else {
        setIsSidebarCollapsed(false);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);


  const toggleSidebar = () => setIsSidebarCollapsed(!isSidebarCollapsed);

  const showSection = (sectionId) => {
    setActiveSection(sectionId);
    if (isMobile) {
      setIsSidebarCollapsed(true);
    }
  };



  const addUser = async (newUser) => {
    await createUser(newUser);
    showNotification('Usuário adicionado com sucesso!');
  };

  const editUser = async (updatedUser) => {
    await updateUser(updatedUser.id, updatedUser);
    showNotification('Alterações salvas com sucesso!');
  };

  const deleteUser = async (id) => {
    await deleteUserFn(id);
    showNotification('Usuário removido com sucesso!');
  };

  const showNotification = (message) => {
    setNotification({ message, show: true });
    setTimeout(() => setNotification({ message: '', show: false }), 3000);
  };

  return (
    <div className="app-container">
      <Sidebar
        isCollapsed={isSidebarCollapsed}
        isMobile={isMobile}
        toggleSidebar={toggleSidebar}
        showSection={showSection}
        onLogout={onLogout}
      />
      <div className="main-content">
        <Header activeSection={activeSection} />
        <main>
          {activeSection === 'dashboard' && <Dashboard />}
          {activeSection === 'kitchen' && <KitchenSection />}
          {activeSection === 'cleaning' && <CleaningSection />}
          {activeSection === 'residents' && (
            <ResidentSection title="Moradores" category="residents" />
          )}
          {activeSection === 'users' && (
            <UserSection
              title="Usuários"
              users={users}
              category="users"
              addUser={addUser}
              editUser={editUser}
              deleteUser={deleteUser}
            />
          )}
        </main>
      </div>
      {isMobile && isSidebarCollapsed && (
        <button className="sidebar-nugget" onClick={toggleSidebar}>
          <i className="fas fa-bars"></i>
        </button>
      )}
      <SuccessNotification message={notification.message} show={notification.show} />
    </div>
  );
}

export default App;