import { useState, useEffect } from 'react';

export default function useUsers() {
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';
  const token = localStorage.getItem('bearerToken');
  const [users, setUsers] = useState([]);

  useEffect(() => {
    async function fetchUsers() {
      try {
        const [loginRes, userRes] = await Promise.all([
          fetch(`${baseUrl}/api/login`, { headers: token ? { Authorization: `${token}` } : {} }),
          fetch(`${baseUrl}/api/usuario`, { headers: token ? { Authorization: `${token}` } : {} }),
        ]);
        if (!loginRes.ok || !userRes.ok) {
          throw new Error('Erro ao buscar usuarios');
        }
        const [logins, usuarios] = await Promise.all([loginRes.json(), userRes.json()]);
        const merged = usuarios.map((u) => {
          const l = logins.find((login) => login.IdUsuario === u.Id) || {};
          return {
            id: u.Id,
            cpf: u.Cpf,
            password: l.Senha,
            name: u.Nome,
            changeDate: u.UltimaModificacao,
          };
        });
        setUsers(merged);
      } catch (err) {
        console.error('Erro ao buscar usuarios:', err);
      }
    }
    fetchUsers();
  }, [baseUrl, token]);

  const createUser = async (userData) => {
    try {
      const usuarioRes = await fetch(`${baseUrl}/api/usuario`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify({
          Cpf: userData.cpf,
          Nome: userData.name,
          UltimaModificacao: userData.changeDate,
          IdEmpresa: userData.companyId || 1,
        }),
      });
      if (!usuarioRes.ok) throw new Error('Erro ao adicionar usuario');
      const newUsuario = await usuarioRes.json();
      const loginRes = await fetch(`${baseUrl}/api/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify({
          IdUsuario: newUsuario.Id,
          Senha: userData.password,
          HostAcesso: userData.hostAccess || null,
          UltimoAcesso: newUsuario.UltimaModificacao,
        }),
      });
      if (!loginRes.ok) throw new Error('Erro ao adicionar login');
      const newLogin = await loginRes.json();
      const merged = {
        id: newUsuario.Id,
        cpf: newUsuario.Cpf,
        password: newLogin.Senha,
        name: newUsuario.Nome,
        changeDate: newUsuario.UltimaModificacao,
      };
      setUsers((prev) => [...prev, merged]);
      return merged;
    } catch (err) {
      console.error('Erro ao adicionar usuario:', err);
      throw err;
    }
  };

  const updateUser = async (id, userData) => {
    try {
      const usuarioRes = await fetch(`${baseUrl}/api/usuario/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify({
          Cpf: userData.cpf,
          Nome: userData.name,
          UltimaModificacao: userData.changeDate,
          IdEmpresa: userData.companyId || 1,
        }),
      });
      if (!usuarioRes.ok) throw new Error('Erro ao atualizar usuario');
      const updatedUsuario = await usuarioRes.json();
      const loginRes = await fetch(`${baseUrl}/api/login/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify({
          Senha: userData.password,
          HostAcesso: userData.hostAccess || null,
          UltimoAcesso: updatedUsuario.UltimaModificacao,
        }),
      });
      if (!loginRes.ok) throw new Error('Erro ao atualizar login');
      const updatedLogin = await loginRes.json();
      const merged = {
        id: updatedUsuario.Id,
        cpf: updatedUsuario.Cpf,
        password: updatedLogin.Senha,
        name: updatedUsuario.Nome,
        changeDate: updatedUsuario.UltimaModificacao,
      };
      setUsers((prev) => prev.map((u) => (u.id === id ? merged : u)));
      return merged;
    } catch (err) {
      console.error('Erro ao atualizar usuario:', err);
      throw err;
    }
  };

  const deleteUser = async (id) => {
    try {
      const loginRes = await fetch(`${baseUrl}/api/login/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `${token}` } : {},
      });
      const usuarioRes = await fetch(`${baseUrl}/api/usuario/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `${token}` } : {},
      });
      if (!loginRes.ok || !usuarioRes.ok) {
        throw new Error('Erro ao apagar usuario');
      }
      setUsers((prev) => prev.filter((u) => u.id !== id));
      return true;
    } catch (err) {
      console.error('Erro ao apagar usuario:', err);
      throw err;
    }
  };

  return { users, createUser, updateUser, deleteUser };
}
