import { useState, useEffect } from 'react';

export default function usePersonalItems() {
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';
  const token = localStorage.getItem('bearerToken');
  const [items, setItems] = useState([]);

  useEffect(() => {
    async function fetchItems() {
      try {
        const response = await fetch(`${baseUrl}/api/personal`, {
          headers: token ? { Authorization: `${token}` } : {},
        });
        if (!response.ok) {
          throw new Error('Erro ao buscar items');
        }
        const data = await response.json();
        setItems(data);
      } catch (err) {
        console.error('Erro ao buscar items pessoais:', err);
      }
    }
    fetchItems();
  }, [baseUrl, token]);

  return items;
}
