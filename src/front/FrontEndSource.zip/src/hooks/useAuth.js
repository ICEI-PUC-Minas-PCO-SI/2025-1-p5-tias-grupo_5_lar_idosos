import { useState } from 'react';

export default function useAuth() {
  const [token, setToken] = useState(() => localStorage.getItem('bearerToken'));
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';

  const handleResponse = async (response) => {
    if (!response.ok) {
      throw new Error('Falha no login');
    }
    const data = await response.json();
    const bearerToken = data.token || data.bearerToken;
    if (bearerToken) {
      localStorage.setItem('bearerToken', bearerToken);
      setToken(bearerToken);
      return { success: true };
    }
    throw new Error('Token não encontrado');
  };

  const loginWithPassword = async ({ login, password }) => {
    try {
      const response = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ IdUsuario: login, Senha: password }),
      });

      return await handleResponse(response);
    } catch (err) {
      console.error('Erro ao efetuar login:', err);
      logout();
      return { success: false, message: err.message };
    }
  };

  const loginWithCpf = async ({ cpf }) => {
    try {
      const response = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cpf }),
      });

      return await handleResponse(response);
    } catch (err) {
      console.error('Erro ao efetuar login:', err);
      logout();
      return { success: false, message: err.message };
    }
  };

  const logout = () => {
    localStorage.removeItem('bearerToken');
    setToken(null);
  };

  return { token, loginWithPassword, loginWithCpf, logout };
}
