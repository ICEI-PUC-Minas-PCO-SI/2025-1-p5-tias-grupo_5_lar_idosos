import { useState, useEffect, useContext } from 'react';
import { AppDataContext } from '../contexts/AppDataContext';

export default function useResidents() {
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';
  const token = localStorage.getItem('bearerToken');
  const [residents, setResidents] = useState([]);
  const { filial, usuario } = useContext(AppDataContext);

  useEffect(() => {
    async function fetchResidents() {
      try {
        const response = await fetch(`${baseUrl}/api/residente`, {
          headers: token ? { Authorization: `${token}` } : {},
        });
        if (!response.ok) {
          throw new Error('Erro ao buscar moradores');
        }
        const data = await response.json();
        setResidents(data);
      } catch (err) {
        console.error('Erro ao buscar moradores:', err);
      }
    }
    fetchResidents();
  }, [baseUrl, token]);

  const createResident = async (residentData) => {
    residentData = { ...residentData, IdFilial: filial?.Id, CriadoPor: usuario?.Id, DataCriacao: new Date() };
    try {
      const response = await fetch(`${baseUrl}/api/residente`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify(residentData),
      });
      if (!response.ok) {
        throw new Error('Erro ao adicionar morador');
      }
      const newResident = await response.json();
      setResidents((prev) => [...prev, newResident]);
      return newResident;
    } catch (err) {
      console.error('Erro ao adicionar morador:', err);
      throw err;
    }
  };

  const updateResident = async (id, residentData) => {
    try {
      const response = await fetch(`${baseUrl}/api/residente/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify(residentData),
      });
      if (!response.ok) {
        throw new Error('Erro ao atualizar morador');
      }
      const updatedResident = await response.json();
      setResidents((prev) => prev.map((r) => (r.Id === residentData.Id ? updatedResident : r)));
      return updatedResident;
    } catch (err) {
      console.error('Erro ao atualizar morador:', err);
      throw err;
    }
  };

  const deleteResident = async (id) => {
    try {
      const response = await fetch(`${baseUrl}/api/residente/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `${token}` } : {},
      });
      if (!response.ok) {
        throw new Error('Erro ao apagar morador');
      }
      setResidents((prev) => prev.filter((r) => r.Id !== id));
      return true;
    } catch (err) {
      console.error('Erro ao apagar morador:', err);
      throw err;
    }
  };

  return { residents, createResident, updateResident, deleteResident };
}

