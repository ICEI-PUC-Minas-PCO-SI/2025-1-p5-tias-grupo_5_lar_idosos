import { useState, useEffect } from 'react';

export default function useCleaningItems() {
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';
  const token = localStorage.getItem('bearerToken');
  const [items, setItems] = useState([]);

  useEffect(() => {
    async function fetchItems() {
      try {
        const response = await fetch(`${baseUrl}/api/cleaning`, {
          headers: token ? { Authorization: `${token}` } : {},
        });
        if (!response.ok) {
          throw new Error('Erro ao buscar items');
        }
        const data = await response.json();
        setItems(data);
      } catch (err) {
        console.error('Erro ao buscar items de limpeza:', err);
      }
    }
    fetchItems();
  }, [baseUrl, token]);

  return items;
}
