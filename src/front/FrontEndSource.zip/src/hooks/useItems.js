import { useState, useEffect, useContext } from 'react';
import { AppDataContext } from '../contexts/AppDataContext';

export default function useItems(category, residentId=null, isDashboard=false) {
  const baseUrl = process.env.REACT_APP_API_BASE_URL || '';
  const token = localStorage.getItem('bearerToken');
  const [items, setItems] = useState([]);
  const { filial, usuario } = useContext(AppDataContext);

  useEffect(() => {
    async function fetchItems() {
      try {
        let url;
        if (category) {
          url = residentId != null
            ? `${baseUrl}/api/item/categoria/${category}/${residentId}/${isDashboard}`
            : `${baseUrl}/api/item/categoria/${category}/${isDashboard}`;
        } else {
          url = `${baseUrl}/api/item`;
        }
        const response = await fetch(url, {
          headers: token ? { Authorization: `${token}` } : {},
        });
        if (!response.ok) {
          throw new Error('Erro ao buscar items');
        }
        const data = await response.json();
        setItems(data);
      } catch (err) {
        console.error('Erro ao buscar items da cozinha:', err);
      }
    }
    fetchItems();
  }, [baseUrl, token, category, residentId]);

  const createItem = async (itemData) => {
    itemData = {...itemData, IdFilial: filial?.Id, CriadoPor: usuario?.Id};

    try {
      const response = await fetch(`${baseUrl}/api/item`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify(itemData),
      });
      if (!response.ok) {
        throw new Error('Erro ao adicionar item');
      }
      const newItem = await response.json();
      setItems((prev) => [...prev, newItem]);
      return newItem;
    } catch (err) {
      console.error('Erro ao adicionar item da cozinha:', err);
      throw err;
    }
  };

  const updateItem = async (id, itemData) => {
    try {
      const response = await fetch(`${baseUrl}/api/item/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `${token}` } : {}),
        },
        body: JSON.stringify(itemData),
      });
      if (!response.ok) {
        throw new Error('Erro ao atualizar item');
      }
      const updatedItem = await response.json();
      setItems((prev) =>
        prev.map((item) => (item.Id === itemData.Id ? updatedItem : item))
      );
      return updatedItem;
    } catch (err) {
      console.error('Erro ao atualizar item da cozinha:', err);
      throw err;
    }
  };

  const deleteItem = async (id) => {
    try {
      const response = await fetch(`${baseUrl}/api/item/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `${token}` } : {},
      });
      if (!response.ok) {
        throw new Error('Erro ao apagar item');
      }
      setItems((prev) => prev.filter((item) => item.Id !== id));
      return true;
    } catch (err) {
      console.error('Erro ao apagar item da cozinha:', err);
      throw err;
    }
  };

  return { items, createItem, updateItem, deleteItem };
}
